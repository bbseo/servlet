-- DB scott
USE scott;

-- Table
DROP TABLE BOARD;

CREATE TABLE BOARD (
	num int primary key,
	title VARCHAR(20),
	author VARCHAR(20),
	email VARCHAR(30),
	content VARCHAR(100),
	password VARCHAR(20),
	writeday VARCHAR(20),
	readnum int
);


ALTER TABLE bt_project ADD FOREIGN KEY (recipient_id) REFERENCES recipient (recipient_id) ON DELETE CASCADE ON UPDATE NO ACTION;
ALTER TABLE bt_project ADD FOREIGN KEY (donor_id)  REFERENCES donor (donor_id) ON DELETE CASCADE ON UPDATE NO ACTION;